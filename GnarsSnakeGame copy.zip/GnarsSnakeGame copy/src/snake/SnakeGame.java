package snake;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;
import java.util.Timer;
import javax.swing.*;

public class SnakeGame {
	

	public static void main(String[] args) {
		new GameFrame();

	}

}

/**
 * 
 */
/**
 * @author Julie
 *
 */
module GnarsSnakeGame {
	requires java.desktop;
}